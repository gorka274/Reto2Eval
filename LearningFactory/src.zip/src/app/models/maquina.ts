export interface Maquina {
  stock: number;
  price: number;
}
